'''Crie um programa que exiba a tabuada de um número fornecido pelo usuário.'''

valor = int(input("Digite um número: "))

for i in range(0, 11):
    mult = valor * i 
    print(mult)