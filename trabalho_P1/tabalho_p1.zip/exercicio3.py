'''Crie um programa que exiba uma contagem regressiva de 10 a 1.'''

for i in range(10,0,-1):
    print(i)