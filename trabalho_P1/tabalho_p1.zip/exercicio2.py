'''Crie um programa que peça ao usuário dois números e mostre a soma deles.'''

num = float(input("Digite um número: "))
num_2 = float(input("Digite um segundo número: "))

num_3 = num + num_2

print("A soma dos dois números é igual a ", num_3)
