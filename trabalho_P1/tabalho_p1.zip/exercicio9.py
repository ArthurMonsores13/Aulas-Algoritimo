'''Crie um programa que inverta uma string fornecida pelo usuário.'''

palavra =  input("Digite seu nome: ")
print(palavra[::-1])