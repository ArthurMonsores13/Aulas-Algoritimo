'''Crie um programa que peça ao usuário um número inteiro e informe se ele é par ou ímpar.'''

num = float(input("Digite um número e vou te dizer se ele é par ou ímpar: "))

if num % 2 == 0:
    print("Seu número mágico é par!")

else:
    print("Seu número mágico é ímpar!")